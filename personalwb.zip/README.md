# PERSONAL WEB-SITE

![Packagist](https://img.shields.io/packagist/l/doctrine/orm.svg)
![Packagist](https://img.shields.io/badge/HTML---%20-blue.svg)
![Packagist](https://img.shields.io/badge/CSS----ff69b4.svg)
![Packagist](https://img.shields.io/badge/JavaScript----yellow.svg)


This is my personal portfólio project, still in development, any tips and enhancements are welcome, thanks for visiting !

